import javax.swing.*;
import java.awt.*;
import java.awt.event.*; 
import javax.swing.table.*; 
import javax.swing.ImageIcon;

public class SuperMarket extends JFrame implements ActionListener,ItemListener  
{
       JPanel mp,p1,p2,p3,p4; 
     
       JLabel lblhead; 
       JLabel lblbillno, lblcname,lblcphone,lbldate; 
       JTextField txtbillno,txtcname,txtcphone; 
	   JLabel l1;
	   ImageIcon i;

       JTable Jtable; 
       DefaultTableModel dt;        
       JScrollPane sp1; 
       JButton bdelete; 

       JLabel lblprid,lblprname,lblprprice,lblprqty;
       JComboBox cmbprid;
       JTextField txtprname,txtprprice,txtprqty; 
       JButton btnadd,btnupdate; 

		JLabel lbltotalitems,lbltotalamount; 
       JTextField txttotalitems,txttotalamount; 
       JButton btnprint; 

       public SuperMarket()
       {
            try { 

                 mp = new JPanel(); 
                 mp.setLayout(null); 

	p1 = new JPanel(); 
                 p1.setLayout(null); 
				 i=new ImageIcon("ic.png");
				 l1=new JLabel(i);
                 lblhead = new JLabel("SUPER MARKET"); 
                 lblhead.setFont(new Font("Times New Roman",3,35));
                 lblbillno = new JLabel("Bill No");
                 lblcname = new JLabel("Customer Name");
				 
				 
				 
                 lblcphone = new JLabel("Phone "); 
                 txtbillno = new JTextField(20);
                 txtcname = new JTextField(20);
                 txtcphone = new JTextField(20); 

                 lblhead.setBounds(290,30,700,30); 
				l1.setBounds(0,0,400,50);
                 lblbillno.setBounds(10,80,50,30); 
                 txtbillno.setBounds(70,80,100,30);
                 lblcname.setBounds(220,80,100,30);
                 txtcname.setBounds(320,80,100,30); 
                 lblcphone.setBounds(450,80,100,30);
                 txtcphone.setBounds(510,80,100,30);
                 
                 p1.add(lblhead); 
                 p1.add(lblbillno); p1.add(txtbillno);
                 p1.add(lblcname); p1.add(txtcname); 
                 p1.add(lblcphone); p1.add(txtcphone);
				p1.add(l1);

                 p1.setBounds(0,0,1000000,150); 
				p1.setBackground(Color.red);
                 mp.add(p1); 
				 p2 = new JPanel();
					p2.setLayout(new BorderLayout());

dt = new DefaultTableModel(); 
                 String [] cols =new String [] {  "No", "ID", "Name", "Quantity","Rate","Bill" } ; 
                 dt.setColumnIdentifiers(cols); 
		Jtable = new JTable(dt); 

                
				
				sp1 =new JScrollPane(Jtable,ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS); 
				//sp1.setBounds(0,80,400,400);
				p2.add(sp1,BorderLayout.CENTER);
				p2.setBounds(0,150,1000,400); 
				//p2.add(Jtable);
				p2.setBackground(Color.red);
				mp.add(p2); 
					p3 = new JPanel();			 
	                 p3.setLayout(new GridLayout(5,2,5,5)); 
		lblprid = new JLabel("Product ID"); 
		lblprname = new JLabel("Name :"); 
		lblprqty = new JLabel("Quantity :"); 
        lblprprice = new JLabel("Price :");

String [] prids = new String[] { "Select", "101","102","103","104","105"}; 
		cmbprid = new JComboBox(prids); 
cmbprid.addItemListener(this); 
		txtprname = new JTextField(20); 
		txtprprice =new JTextField(20); 
		txtprqty = new JTextField(20); 
		
		btnadd = new JButton("Add"); 
		btnupdate = new JButton("Update"); 
        btnadd.addActionListener(this); 
		p3.add(lblprid); p3.add(cmbprid); 
		p3.add(lblprname); p3.add(txtprname); 
		p3.add(lblprprice); p3.add(txtprprice); 
		p3.add(lblprqty); p3.add(txtprqty); 
		p3.add(btnadd); p3.add(btnupdate); 
		p3.setBounds(1040,160,280,200); 	
		p3.setBackground(Color.blue);				
		mp.add(p3); 
             getContentPane().add(mp); setSize(800,500);
             setVisible(true); 
             setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
     }
  catch(Exception e) { System.out.println(e); } 
 
   
       }

       public void itemStateChanged(ItemEvent ie)
       {
	try { 
		txtprname.setText("Some Product"); 
		txtprprice.setText("120.50"); 


	    }
             catch(Exception e) { } 
	
       }


       public void actionPerformed(ActionEvent ae)
       {
	try { 
	         Object [] data = new Object[6]; 

	         data[0] = 1; 
	         data[1] = cmbprid.getSelectedItem();
	         data[2] = txtprname.getText(); 
                          data[3] = txtprprice.getText(); 
                          data[4] = txtprqty.getText(); 
                          double prprice  = Double.parseDouble(txtprprice.getText());
	         int prqty = Integer.parseInt(txtprqty.getText());
	         double prbill = prprice*prqty; 
	         data[5] = prbill; 
	         dt.addRow(data); 	         	


	    }
              catch(Exception e) { } 
			  
       
				p4 = new JPanel();
				 				
				p4.setBounds(0,500,1000,270); 
				p4.setBackground(Color.black);
                 mp.add(p4); 
	   }
	   
	   
       public static void main(String args[])
       {
	new SuperMarket(); 
       } 
	
				
}
//p3.setBounds(510,160,280,200); 
			



//lbltotalitems,lbltotalamount JTextField txttotalitems,txttotalamount;  JButton btnprint; 
