import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
 

public class superlogin extends JFrame implements ActionListener 
{
         JPanel p;
         JLabel lbluser,lblpass; 
         JTextField txtuser;
         JPasswordField txtpass; 
         JButton btnlogin; 

         public superlogin()
         {
	p = new JPanel();
                 lbluser = new JLabel("User : "); 
                 lblpass = new JLabel("Password : ");
                 txtuser = new JTextField(20);
                 txtpass = new JPasswordField(20); 
                 btnlogin = new JButton("Login");
                 btnlogin.addActionListener(this); 

                 p.setLayout(new GridLayout(3,2,5,5)); 
                 p.add(lbluser); p.add(txtuser);
                 p.add(lblpass); p.add(txtpass);
                 p.add(btnlogin); 

                 getContentPane().add(p); 
                 setSize(300,300); setVisible(true);
                 setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
                 Toolkit tk = Toolkit.getDefaultToolkit(); 
                 Dimension d = tk.getScreenSize(); 
                 setLocation(d.width/2-250,d.height/2-100); 
         }
         public void actionPerformed(ActionEvent ae)
         {
                 try { 
                            String user = txtuser.getText();
                            String pass = txtpass.getText(); 
                            if(user.equals("abc") && pass.equals("pqr"))
                            {
		  new col();      
		  dispose();
                            }
                           else if(user.equals("admin") && pass.equals("admin"))
	           {
		new col();
		dispose(); 
                            }
                      }
                catch(Exception e) {} 
         }
         public static void main(String args[])
         {
	new superlogin(); 
         }
}